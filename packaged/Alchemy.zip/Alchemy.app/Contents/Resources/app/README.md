# Alchemy
:fist: Drag and Drop :hand: file converter utility (made with Electron and React)

`⌘-8` to toggle viewing Alchemy
