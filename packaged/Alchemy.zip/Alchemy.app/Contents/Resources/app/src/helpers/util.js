function replaceSpaceCharacters(str) {
  return str.replace(/\s/g, '\\ ')
}

module.exports = {
  replaceSpaceCharacters
}
